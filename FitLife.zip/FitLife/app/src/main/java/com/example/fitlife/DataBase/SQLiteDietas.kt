package com.example.fitlife.DataBase

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SQLiteDietas(
    context: Context?,
    name: String?,
    factory: SQLiteDatabase.CursorFactory?,
    version: Int
) : SQLiteOpenHelper(context, "dietas.db", factory, version) {
    override fun onCreate(db: SQLiteDatabase?) {
        //Para la Tabla Registro
        db?.execSQL("CREATE TABLE dietas (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre text, contenido text, tipo text, precio REAL, idcreador INTEGER)")

    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        TODO("Not yet implemented")
    }
}