package com.example.fitlife.DataBase

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SQLiteUsuarios(
    context: Context?,
    name: String?,
    factory: SQLiteDatabase.CursorFactory?,
    version: Int
) : SQLiteOpenHelper(context, "usuarios.db", factory, version) {
    override fun onCreate(db: SQLiteDatabase?) {
        //Para la Tabla Registro
        db?.execSQL("CREATE TABLE Registro (id INTEGER PRIMARY KEY AUTOINCREMENT, usuario text, password text)")
        //Para la Tabla Información
        db?.execSQL("CREATE TABLE Informacion (id INTEGER PRIMARY KEY AUTOINCREMENT,usuario_id INTEGER ,nombre TEXT, " +
                "peso REAL, genero text,altura INTEGER, edad INTEGER, FOREIGN KEY(usuario_id) REFERENCES registro(id))")
        //Para la Tabla Progreso
        db?.execSQL("CREATE TABLE Progreso(id INTEGER PRIMARY KEY AUTOINCREMENT, usuario_id INTEGER, fecha text, despcripcion text," +
                " anotacion text,Objetivo text,FOREIGN KEY(usuario_id) REFERENCES registro(id))")
        //Añadir de base
        val UsuarioAdmin = " Insert INTO registro (usuario,password) VALUES ('Admin','Admin')"
        db?.execSQL(UsuarioAdmin)

        val AñadirInfo = "INSERT INTO informacion (usuario_id, nombre, peso, genero, altura, edad) \n" +
                "    VALUES (1, 'Admin Supremo', 70.0, 'Masculino', 175, 25)"
        db?.execSQL(AñadirInfo)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        TODO("Not yet implemented")
    }
}